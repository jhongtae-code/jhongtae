import json, os, re, subprocess, sys, threading, time, webbrowser
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse

BASE=os.path.dirname(os.path.abspath(__file__))
PORT=8765

def sgf_prop(root,key,default=''):
    m=re.search(r'(?:^|[;(])'+re.escape(key)+r'\[([^\]]*)\]',root)
    return m.group(1) if m else default

def sgf_to_query(text, visits):
    root_end=text.find(';',2)
    root=text[:root_end if root_end>=0 else len(text)]
    size=int(sgf_prop(root,'SZ','19') or 19)
    komi=float(sgf_prop(root,'KM','7.5') or 7.5)
    rules='japanese'
    ru=sgf_prop(root,'RU','').lower()
    if 'chinese' in ru: rules='chinese'
    moves=[]
    letters='ABCDEFGHJKLMNOPQRSTUVWXYZ'
    for color,coord in re.findall(r';\s*([BW])\[([^\]]*)\]',text):
        if not coord:
            loc='pass'
        else:
            x=ord(coord[0])-97; y=ord(coord[1])-97
            if x<0 or y<0 or x>=size or y>=size: continue
            loc=f'{letters[x]}{size-y}'
        moves.append([color,loc])
    return {
      'id':'hongtai-game','moves':moves,'rules':rules,'komi':komi,
      'boardXSize':size,'boardYSize':size,
      'analyzeTurns':list(range(len(moves)+1)),
      'maxVisits':int(visits),'analysisPVLen':8
    }

def run_analysis(payload):
    exe=payload.get('katagoPath','').strip()
    model=payload.get('modelPath','').strip()
    cfg=payload.get('configPath','analysis_hongtai.cfg').strip()
    if not os.path.isabs(cfg): cfg=os.path.join(BASE,cfg)
    for path,label in [(exe,'KataGo 실행 파일'),(model,'신경망 모델'),(cfg,'분석 설정 파일')]:
        if not os.path.exists(path): raise FileNotFoundError(f'{label}을 찾을 수 없습니다: {path}')
    query=sgf_to_query(payload.get('sgf',''),payload.get('visits',50))
    cmd=[exe,'analysis','-config',cfg,'-model',model]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',bufsize=1)
    proc.stdin.write(json.dumps(query,separators=(',',':'))+'\n'); proc.stdin.flush(); proc.stdin.close()
    expected=len(query['analyzeTurns']); results={}; errors=[]
    deadline=time.time()+max(180, expected*8)
    while len(results)<expected and time.time()<deadline:
        line=proc.stdout.readline()
        if not line:
            if proc.poll() is not None: break
            time.sleep(.05); continue
        try:
            obj=json.loads(line)
            if obj.get('id')=='hongtai-game' and not obj.get('isDuringSearch',False):
                results[int(obj.get('turnNumber',0))]=obj
        except Exception:
            errors.append(line.strip())
    if proc.poll() is None: proc.terminate()
    stderr=proc.stderr.read()[-4000:]
    if not results:
        raise RuntimeError('KataGo 분석 결과가 없습니다.\n'+stderr)
    compact=[]
    for turn in sorted(results):
        obj=results[turn]; root=obj.get('rootInfo',{}); infos=sorted(obj.get('moveInfos',[]),key=lambda x:x.get('order',999))
        best=infos[0] if infos else {}
        compact.append({'move':turn,'blackWinrate':round(float(root.get('winrate',.5))*100,2),'scoreLead':round(float(root.get('scoreLead',0)),2),'bestMove':best.get('move','-'),'pv':best.get('pv',[])[:8],'visits':root.get('visits',0)})
    return {'ok':True,'positions':compact,'count':len(compact),'stderr':stderr[-800:]}

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        path=urlparse(path).path.lstrip('/') or 'index.html'
        return os.path.join(BASE,path)
    def do_POST(self):
        if self.path!='/analyze': self.send_error(404); return
        try:
            n=int(self.headers.get('Content-Length','0')); payload=json.loads(self.rfile.read(n).decode('utf-8'))
            result=run_analysis(payload); data=json.dumps(result,ensure_ascii=False).encode('utf-8'); self.send_response(200)
        except Exception as e:
            data=json.dumps({'ok':False,'error':str(e)},ensure_ascii=False).encode('utf-8'); self.send_response(500)
        self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def log_message(self,fmt,*args): pass

if __name__=='__main__':
    os.chdir(BASE)
    url=f'http://127.0.0.1:{PORT}/'
    threading.Timer(1.0,lambda:webbrowser.open(url)).start()
    print('Hongtai Go Studio v0.4 실행 중:',url)
    print('이 창을 닫으면 Studio도 종료됩니다.')
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()
