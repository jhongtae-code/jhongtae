# Hongtai Go Studio v0.4

## 실행
1. Python 3를 설치합니다. 설치할 때 **Add Python to PATH**를 체크합니다.
2. `실행하기.bat`을 실행합니다. 브라우저가 자동으로 열립니다.
3. SGF 파일을 불러옵니다.
4. KataGo 실행 파일과 신경망 모델 경로를 확인합니다.
5. `KataGo AI 분석`을 누릅니다.
6. 분석 완료 후 재생 버튼을 누르면 기본적으로 **3초에 한 수씩** 자동 재생됩니다.

## 권장 설정 — Ryzen 5 1400 / RX 560 / RAM 8GB
- OpenCL KataGo 사용
- Visits: 50부터 시작
- 긴 기보 분석이 너무 느리면 Visits를 20~30으로 낮추기
- 분석 중 OBS와 다른 무거운 프로그램은 닫기

## v0.4 기능
- SGF 로딩 및 재생
- 3초 자동 착수
- KataGo JSON Analysis Engine 연동
- 각 수의 흑 승률, 예상 집차, AI 추천수, PV 자동 표시
- 전체 승률 그래프 자동 생성
- OBS 녹화 모드

## 주의
브라우저에서 `index.html`만 직접 열면 AI 분석 기능이 작동하지 않습니다. 반드시 `실행하기.bat`으로 실행하세요.
