'use strict';

const $ = (id) => document.getElementById(id);
const boardCanvas = $('board');
const boardCtx = boardCanvas.getContext('2d');
const chartCanvas = $('winrateChart');
const chartCtx = chartCanvas.getContext('2d');

const state = {
  size: 19,
  moves: [],
  setupBlack: [],
  setupWhite: [],
  current: 0,
  meta: {},
  coords: true,
  numbers: false,
  timer: null,
  winratePoints: [{move:0, value:50}],
};

function decodeSgfValue(value) {
  return value.replace(/\\\]/g, ']').replace(/\\\\/g, '\\').replace(/\\\n/g, '');
}

function getProp(text, key) {
  const m = text.match(new RegExp('(?:^|[;(])' + key + '\\[([^\\]]*)\\]'));
  return m ? decodeSgfValue(m[1]) : '';
}

function getAllProps(text, key) {
  const regex = new RegExp(key + '((?:\\[[^\\]]*\\])+)', 'g');
  const results = [];
  let match;
  while ((match = regex.exec(text))) {
    const vals = [...match[1].matchAll(/\[([^\]]*)\]/g)].map(x => decodeSgfValue(x[1]));
    results.push(...vals);
  }
  return results;
}

function parseSgf(text) {
  const rootEnd = text.indexOf(';', 2) > -1 ? text.indexOf(';', 2) : text.length;
  const root = text.slice(0, rootEnd);
  const size = parseInt(getProp(root, 'SZ') || '19', 10);
  if (size < 2 || size > 25) throw new Error('지원하지 않는 바둑판 크기입니다.');

  const moves = [];
  const moveRegex = /;\s*([BW])\[([^\]]*)\]/g;
  let m;
  while ((m = moveRegex.exec(text))) {
    moves.push({ color: m[1], coord: m[2], comment: '' });
  }

  return {
    size,
    moves,
    setupBlack: getAllProps(root, 'AB'),
    setupWhite: getAllProps(root, 'AW'),
    meta: {
      black: getProp(root, 'PB') || '-',
      white: getProp(root, 'PW') || '-',
      result: getProp(root, 'RE') || '-',
      komi: getProp(root, 'KM') || '-',
      event: getProp(root, 'EV'),
      date: getProp(root, 'DT'),
      name: getProp(root, 'GN'),
    }
  };
}

function coordToPoint(coord) {
  if (!coord || coord.length < 2) return null;
  return {x: coord.charCodeAt(0)-97, y: coord.charCodeAt(1)-97};
}

function boardGeometry() {
  const pad = 58;
  const usable = boardCanvas.width - pad*2;
  const step = usable / (state.size-1);
  return {pad, step};
}

function buildPosition() {
  const stones = new Map();
  for (const c of state.setupBlack) { const p=coordToPoint(c); if(p) stones.set(`${p.x},${p.y}`, {color:'B', move:0}); }
  for (const c of state.setupWhite) { const p=coordToPoint(c); if(p) stones.set(`${p.x},${p.y}`, {color:'W', move:0}); }
  for (let i=0;i<state.current;i++) {
    const move = state.moves[i];
    const p = coordToPoint(move.coord);
    if (p) stones.set(`${p.x},${p.y}`, {color:move.color, move:i+1});
  }
  return stones;
}

function drawBoard() {
  const ctx = boardCtx;
  const {pad,step} = boardGeometry();
  ctx.clearRect(0,0,boardCanvas.width,boardCanvas.height);
  const grad=ctx.createLinearGradient(0,0,boardCanvas.width,boardCanvas.height);
  grad.addColorStop(0,'#efc477'); grad.addColorStop(1,'#c98a3d');
  ctx.fillStyle=grad; ctx.fillRect(0,0,boardCanvas.width,boardCanvas.height);

  ctx.strokeStyle='#3e250e'; ctx.lineWidth=1.7;
  for(let i=0;i<state.size;i++){
    const v=pad+i*step;
    ctx.beginPath();ctx.moveTo(pad,v);ctx.lineTo(pad+(state.size-1)*step,v);ctx.stroke();
    ctx.beginPath();ctx.moveTo(v,pad);ctx.lineTo(v,pad+(state.size-1)*step);ctx.stroke();
  }

  const hoshi = state.size===19 ? [3,9,15] : state.size===13 ? [3,6,9] : state.size===9 ? [2,4,6] : [];
  ctx.fillStyle='#2b1808';
  hoshi.forEach(x=>hoshi.forEach(y=>{ctx.beginPath();ctx.arc(pad+x*step,pad+y*step,5,0,Math.PI*2);ctx.fill();}));

  if(state.coords){
    ctx.fillStyle='#2a190b';ctx.font='bold 20px Segoe UI';ctx.textAlign='center';ctx.textBaseline='middle';
    const letters='ABCDEFGHJKLMNOPQRSTUVWXYZ';
    for(let i=0;i<state.size;i++){
      ctx.fillText(letters[i],pad+i*step,24);ctx.fillText(letters[i],pad+i*step,boardCanvas.height-24);
      const n=String(state.size-i);ctx.fillText(n,26,pad+i*step);ctx.fillText(n,boardCanvas.width-26,pad+i*step);
    }
  }

  const stones=buildPosition();
  stones.forEach((s,key)=>{
    const [x,y]=key.split(',').map(Number); const cx=pad+x*step, cy=pad+y*step, r=step*.43;
    const g=ctx.createRadialGradient(cx-r*.35,cy-r*.35,r*.1,cx,cy,r);
    if(s.color==='B'){g.addColorStop(0,'#565656');g.addColorStop(.45,'#171717');g.addColorStop(1,'#000');}
    else{g.addColorStop(0,'#fff');g.addColorStop(.7,'#eee');g.addColorStop(1,'#aaa');}
    ctx.shadowColor='#0008';ctx.shadowBlur=8;ctx.shadowOffsetY=4;ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill();ctx.shadowColor='transparent';
    if(state.numbers && s.move>0){ctx.fillStyle=s.color==='B'?'#fff':'#111';ctx.font=`bold ${Math.max(11,step*.28)}px Segoe UI`;ctx.fillText(String(s.move),cx,cy+1);}
  });

  if(state.current>0){
    const last=coordToPoint(state.moves[state.current-1].coord);
    if(last){ctx.strokeStyle='#54f27f';ctx.lineWidth=6;ctx.beginPath();ctx.arc(pad+last.x*step,pad+last.y*step,step*.29,0,Math.PI*2);ctx.stroke();}
  }
}

function drawChart(){
  const ctx=chartCtx,w=chartCanvas.width,h=chartCanvas.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#081522';ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='#244862';ctx.lineWidth=1;ctx.font='12px Segoe UI';ctx.fillStyle='#9eb4c8';
  [0,25,50,75,100].forEach(v=>{const y=h-24-v*(h-42)/100;ctx.beginPath();ctx.moveTo(34,y);ctx.lineTo(w-12,y);ctx.stroke();ctx.fillText(v+'%',4,y+4);});
  const maxMove=Math.max(1,state.moves.length,...state.winratePoints.map(p=>p.move));
  const pts=[...state.winratePoints].sort((a,b)=>a.move-b.move);
  function line(valueFn,color){ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();pts.forEach((p,i)=>{const x=34+p.move/maxMove*(w-48);const y=h-24-valueFn(p.value)*(h-42)/100;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();}
  line(v=>v,'#57e07b');line(v=>100-v,'#ff5c62');
  const x=34+state.current/maxMove*(w-48);ctx.strokeStyle='#fff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,8);ctx.lineTo(x,h-20);ctx.stroke();
}

function updateUI(){
  drawBoard();drawChart();
  $('moveNo').textContent=state.current; $('timeline').max=state.moves.length; $('timeline').value=state.current; $('timelineLabel').textContent=`${state.current} / ${state.moves.length}`;
  $('turn').textContent=(state.current===0?'흑':state.moves[state.current-1].color==='B'?'백':'흑');
  $('blackPlayer').textContent=state.meta.black||'-';$('whitePlayer').textContent=state.meta.white||'-';$('result').textContent=state.meta.result||'-';$('komi').textContent=state.meta.komi||'-';
  $('gameTitle').textContent=state.meta.name||state.meta.event||[state.meta.black,state.meta.white].filter(x=>x&&x!=='-').join(' vs ')||'SGF 대국';
  $('dropHint').style.display=state.moves.length||state.setupBlack.length||state.setupWhite.length?'none':'grid';
}

async function loadFile(file){
  try{
    const text=await file.text();const parsed=parseSgf(text);Object.assign(state,parsed,{current:0,winratePoints:[{move:0,value:50}]});
    $('sceneMemo').value=`파일: ${file.name}\n총 착수: ${state.moves.length}수`;
    updateUI();
  }catch(e){alert('SGF를 읽지 못했습니다: '+e.message);}
}

function setMove(n){state.current=Math.max(0,Math.min(state.moves.length,n));updateUI();}
function stopPlay(){if(state.timer){clearInterval(state.timer);state.timer=null;$('playBtn').textContent='▶';}}
function togglePlay(){if(state.timer){stopPlay();return;}if(state.current>=state.moves.length)state.current=0;$('playBtn').textContent='Ⅱ';state.timer=setInterval(()=>{if(state.current>=state.moves.length){stopPlay();return;}state.current++;updateUI();},Number($('speedSelect').value));}
function setWinrate(v){v=Math.max(0,Math.min(100,Number(v)||0));$('blackWinrate').textContent=Math.round(v);$('winBar').style.width=v+'%';$('winrateInput').value=v;}

$('openBtn').onclick=()=>$('fileInput').click();$('fileInput').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('firstBtn').onclick=()=>{stopPlay();setMove(0)};$('prevBtn').onclick=()=>{stopPlay();setMove(state.current-1)};$('nextBtn').onclick=()=>{stopPlay();setMove(state.current+1)};$('lastBtn').onclick=()=>{stopPlay();setMove(state.moves.length)};$('playBtn').onclick=togglePlay;
$('coordsToggle').onchange=e=>{state.coords=e.target.checked;drawBoard()};$('numbersToggle').onchange=e=>{state.numbers=e.target.checked;drawBoard()};
$('winrateInput').oninput=e=>setWinrate(e.target.value);$('recommendationInput').oninput=e=>$('recommendation').textContent=e.target.value.toUpperCase();
$('addPointBtn').onclick=()=>{const v=Number($('winrateInput').value);state.winratePoints=state.winratePoints.filter(p=>p.move!==state.current);state.winratePoints.push({move:state.current,value:Math.max(0,Math.min(100,v))});drawChart();};
$('clearPointsBtn').onclick=()=>{state.winratePoints=[{move:0,value:50}];drawChart();};
$('timeline').oninput=e=>{stopPlay();setMove(Number(e.target.value));};
$('recordingBtn').onclick=async()=>{document.body.classList.toggle('recording');$('recordingBtn').textContent=document.body.classList.contains('recording')?'녹화 종료':'녹화 모드'; if(document.body.classList.contains('recording')&&!document.fullscreenElement){try{await document.documentElement.requestFullscreen()}catch(_){}}};
$('fullscreenBtn').onclick=async()=>{try{if(!document.fullscreenElement){await document.documentElement.requestFullscreen();document.body.classList.add('fullscreen-ui')}else{await document.exitFullscreen();}}catch(e){alert('전체화면 전환 실패: '+e.message)}};
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)document.body.classList.remove('fullscreen-ui')});

const dz=$('dropZone');['dragenter','dragover'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('dragover')}));['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('dragover')}));dz.addEventListener('drop',e=>{const f=[...e.dataTransfer.files].find(f=>f.name.toLowerCase().endsWith('.sgf'));if(f)loadFile(f);else alert('SGF 파일을 놓아주세요.')});
window.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName))return;if(e.key==='ArrowLeft')setMove(state.current-1);if(e.key==='ArrowRight')setMove(state.current+1);if(e.key===' ') {e.preventDefault();togglePlay();}if(e.key.toLowerCase()==='r'){$('recordingBtn').click();}if(e.key==='Escape'&&document.body.classList.contains('recording')){$('recordingBtn').click();}});

setWinrate(50);updateUI();
