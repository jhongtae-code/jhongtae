﻿@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Hongtai Go Studio v0.5.1

echo [Hongtai Go Studio] 서버를 시작합니다...
echo.

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 studio_server.py
  goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
  python studio_server.py
  goto :end
)

echo Python 3를 찾을 수 없습니다.
echo Python 설치 시 Add Python to PATH를 체크했는지 확인하세요.

:end
echo.
echo 프로그램이 종료되었습니다. 위에 오류 메시지가 있으면 화면을 캡처해 주세요.
pause
