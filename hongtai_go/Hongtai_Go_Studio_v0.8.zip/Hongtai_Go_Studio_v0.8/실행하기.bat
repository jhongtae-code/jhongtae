@echo off
setlocal
cd /d "%~dp0"
title Hongtai Go Studio v0.5.2
echo Starting Hongtai Go Studio...
echo.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 studio_server.py
  goto :done
)
where python >nul 2>nul
if not errorlevel 1 (
  python studio_server.py
  goto :done
)
echo Python 3 was not found.
echo Reinstall Python and enable "Add python.exe to PATH".
:done
echo.
echo Hongtai Go Studio has stopped.
pause
