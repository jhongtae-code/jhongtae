# Hongtai Go Studio v0.5.2

1. Double-click `실행하기.bat`.
2. Keep the command window open while using the Studio.
3. If Chrome does not open automatically, copy the local address shown in the command window (for example `http://127.0.0.1:8765/`) into Chrome.

This patch fixes the Windows batch-file encoding problem and a Python startup syntax error in v0.5.1.
