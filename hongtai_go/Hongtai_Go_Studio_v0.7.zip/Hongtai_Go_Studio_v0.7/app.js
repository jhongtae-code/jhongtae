'use strict';

const $ = (id) => document.getElementById(id);
const boardCanvas = $('board');
const boardCtx = boardCanvas.getContext('2d');
const chartCanvas = $('winrateChart');
const chartCtx = chartCanvas.getContext('2d');

const state = {
  size: 19,
  moves: [],
  setupBlack: [],
  setupWhite: [],
  setupEmpty: [],
  current: 0,
  meta: {},
  coords: true,
  numbers: false,
  timer: null,
  winratePoints: [{move:0, value:50}],
  analysis: new Map(),
  sgfText: '',
  analysisJobId: null,
  analysisPoll: null,
};

let audioContext = null;
function ensureAudioContext(){
  if(!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
  if(audioContext.state === 'suspended') audioContext.resume();
  return audioContext;
}
function playStoneSound(){
  const toggle = $('soundToggle');
  if(toggle && !toggle.checked) return;
  try{
    const ac=ensureAudioContext();
    const now=ac.currentTime;
    const volume=(Number($('soundVolume')?.value ?? 70)/100)*0.42;
    const osc=ac.createOscillator();
    const gain=ac.createGain();
    osc.type='sine'; osc.frequency.setValueAtTime(520,now); osc.frequency.exponentialRampToValueAtTime(170,now+0.045);
    gain.gain.setValueAtTime(volume,now); gain.gain.exponentialRampToValueAtTime(0.001,now+0.065);
    osc.connect(gain).connect(ac.destination); osc.start(now); osc.stop(now+0.07);
    const buffer=ac.createBuffer(1,Math.floor(ac.sampleRate*0.025),ac.sampleRate);
    const data=buffer.getChannelData(0); for(let i=0;i<data.length;i++) data[i]=(Math.random()*2-1)*(1-i/data.length);
    const noise=ac.createBufferSource(), ng=ac.createGain(), filter=ac.createBiquadFilter();
    noise.buffer=buffer; filter.type='bandpass'; filter.frequency.value=1350; filter.Q.value=1.2;
    ng.gain.setValueAtTime(volume*0.35,now); ng.gain.exponentialRampToValueAtTime(0.001,now+0.025);
    noise.connect(filter).connect(ng).connect(ac.destination); noise.start(now); noise.stop(now+0.03);
  }catch(_){ }
}

function parseSgfCollection(text) {
  let i = 0;
  const len = text.length;

  function skipWs() { while (i < len && /\s/.test(text[i])) i++; }
  function readIdent() {
    let out = '';
    while (i < len && /[A-Za-z]/.test(text[i])) out += text[i++];
    return out.toUpperCase();
  }
  function readValue() {
    if (text[i] !== '[') throw new Error('SGF 속성값 형식이 올바르지 않습니다.');
    i++;
    let out = '';
    while (i < len) {
      const ch = text[i++];
      if (ch === ']') return out;
      if (ch === '\\') {
        if (i >= len) break;
        const next = text[i++];
        if (next === '\r' && text[i] === '\n') i++;
        if (next === '\n' || next === '\r') continue;
        out += next;
      } else out += ch;
    }
    throw new Error('닫히지 않은 SGF 속성값이 있습니다.');
  }
  function readNode() {
    if (text[i] !== ';') throw new Error('SGF 노드를 읽을 수 없습니다.');
    i++;
    const props = {};
    while (i < len) {
      skipWs();
      if (!/[A-Za-z]/.test(text[i] || '')) break;
      const key = readIdent();
      skipWs();
      const vals = [];
      while (text[i] === '[') { vals.push(readValue()); skipWs(); }
      if (vals.length) props[key] = (props[key] || []).concat(vals);
    }
    return props;
  }
  function readTree() {
    skipWs();
    if (text[i] !== '(') throw new Error('SGF 게임 트리가 없습니다.');
    i++;
    const sequence = [];
    const children = [];
    while (i < len) {
      skipWs();
      if (text[i] === ';') sequence.push(readNode());
      else if (text[i] === '(') children.push(readTree());
      else if (text[i] === ')') { i++; break; }
      else i++;
    }
    return { sequence, children };
  }
  skipWs();
  const trees = [];
  while (i < len) { skipWs(); if (text[i] === '(') trees.push(readTree()); else i++; }
  if (!trees.length) throw new Error('SGF 게임을 찾지 못했습니다.');
  return trees;
}

function parseSgf(text) {
  const trees = parseSgfCollection(text.replace(/^\uFEFF/, ''));
  const tree = trees[0];
  if (!tree.sequence.length) throw new Error('SGF 메인 수순이 비어 있습니다.');
  const root = tree.sequence[0];
  const prop = (k, d='') => root[k]?.[0] ?? d;
  const size = parseInt(prop('SZ', '19'), 10);
  if (!Number.isFinite(size) || size < 2 || size > 25) throw new Error('지원하지 않는 바둑판 크기입니다.');

  const nodes = [];
  function appendMainLine(t) {
    nodes.push(...t.sequence);
    if (t.children.length) appendMainLine(t.children[0]);
  }
  appendMainLine(tree);

  const moves = [];
  for (const node of nodes.slice(1)) {
    if (node.B) moves.push({ color:'B', coord:node.B[0] || '', comment:node.C?.[0] || '' });
    else if (node.W) moves.push({ color:'W', coord:node.W[0] || '', comment:node.C?.[0] || '' });
  }

  return {
    size,
    moves,
    setupBlack: root.AB || [],
    setupWhite: root.AW || [],
    setupEmpty: root.AE || [],
    meta: {
      black: prop('PB','-'), white: prop('PW','-'), result: prop('RE','-'),
      komi: prop('KM','-'), event: prop('EV',''), date: prop('DT',''),
      name: prop('GN',''), rules: prop('RU',''),
    },
    collectionCount: trees.length,
  };
}


function coordToPoint(coord) {
  if (!coord || coord.length < 2) return null;
  return {x: coord.charCodeAt(0)-97, y: coord.charCodeAt(1)-97};
}

function boardGeometry() {
  const pad = 58;
  const usable = boardCanvas.width - pad*2;
  const step = usable / (state.size-1);
  return {pad, step};
}

function buildPosition() {
  const board = Array.from({length: state.size}, () => Array(state.size).fill(null));
  const onBoard = (x,y) => x>=0 && y>=0 && x<state.size && y<state.size;
  const neighbors = (x,y) => [[x-1,y],[x+1,y],[x,y-1],[x,y+1]].filter(([a,b])=>onBoard(a,b));
  const setCoord = (coord, stone) => { const p=coordToPoint(coord); if(p && onBoard(p.x,p.y)) board[p.y][p.x]=stone; };
  state.setupBlack.forEach(c=>setCoord(c,{color:'B',move:0}));
  state.setupWhite.forEach(c=>setCoord(c,{color:'W',move:0}));
  (state.setupEmpty||[]).forEach(c=>setCoord(c,null));

  function groupAt(x,y) {
    const color=board[y][x]?.color; if(!color) return {stones:[],liberties:0};
    const stack=[[x,y]], seen=new Set(), stones=[], libs=new Set();
    while(stack.length){
      const [cx,cy]=stack.pop(), key=`${cx},${cy}`; if(seen.has(key)) continue; seen.add(key); stones.push([cx,cy]);
      for(const [nx,ny] of neighbors(cx,cy)){
        if(!board[ny][nx]) libs.add(`${nx},${ny}`);
        else if(board[ny][nx].color===color && !seen.has(`${nx},${ny}`)) stack.push([nx,ny]);
      }
    }
    return {stones,liberties:libs.size};
  }
  function removeGroup(group){ group.stones.forEach(([x,y])=>board[y][x]=null); }

  for(let i=0;i<state.current;i++){
    const move=state.moves[i], p=coordToPoint(move.coord); if(!p || !onBoard(p.x,p.y)) continue;
    board[p.y][p.x]={color:move.color,move:i+1};
    const enemy=move.color==='B'?'W':'B';
    for(const [nx,ny] of neighbors(p.x,p.y)){
      if(board[ny][nx]?.color===enemy){ const g=groupAt(nx,ny); if(g.liberties===0) removeGroup(g); }
    }
    const own=groupAt(p.x,p.y); if(own.liberties===0) removeGroup(own);
  }
  const stones=new Map();
  for(let y=0;y<state.size;y++) for(let x=0;x<state.size;x++) if(board[y][x]) stones.set(`${x},${y}`,board[y][x]);
  return stones;
}

function drawBoard() {
  const ctx = boardCtx;
  const {pad,step} = boardGeometry();
  ctx.clearRect(0,0,boardCanvas.width,boardCanvas.height);
  const grad=ctx.createLinearGradient(0,0,boardCanvas.width,boardCanvas.height);
  grad.addColorStop(0,'#efc477'); grad.addColorStop(1,'#c98a3d');
  ctx.fillStyle=grad; ctx.fillRect(0,0,boardCanvas.width,boardCanvas.height);

  ctx.strokeStyle='#3e250e'; ctx.lineWidth=1.7;
  for(let i=0;i<state.size;i++){
    const v=pad+i*step;
    ctx.beginPath();ctx.moveTo(pad,v);ctx.lineTo(pad+(state.size-1)*step,v);ctx.stroke();
    ctx.beginPath();ctx.moveTo(v,pad);ctx.lineTo(v,pad+(state.size-1)*step);ctx.stroke();
  }

  const hoshi = state.size===19 ? [3,9,15] : state.size===13 ? [3,6,9] : state.size===9 ? [2,4,6] : [];
  ctx.fillStyle='#2b1808';
  hoshi.forEach(x=>hoshi.forEach(y=>{ctx.beginPath();ctx.arc(pad+x*step,pad+y*step,5,0,Math.PI*2);ctx.fill();}));

  if(state.coords){
    ctx.fillStyle='#2a190b';ctx.font='bold 20px Segoe UI';ctx.textAlign='center';ctx.textBaseline='middle';
    const letters='ABCDEFGHJKLMNOPQRSTUVWXYZ';
    for(let i=0;i<state.size;i++){
      ctx.fillText(letters[i],pad+i*step,24);ctx.fillText(letters[i],pad+i*step,boardCanvas.height-24);
      const n=String(state.size-i);ctx.fillText(n,26,pad+i*step);ctx.fillText(n,boardCanvas.width-26,pad+i*step);
    }
  }

  const stones=buildPosition();
  stones.forEach((s,key)=>{
    const [x,y]=key.split(',').map(Number); const cx=pad+x*step, cy=pad+y*step, r=step*.43;
    const g=ctx.createRadialGradient(cx-r*.35,cy-r*.35,r*.1,cx,cy,r);
    if(s.color==='B'){g.addColorStop(0,'#565656');g.addColorStop(.45,'#171717');g.addColorStop(1,'#000');}
    else{g.addColorStop(0,'#fff');g.addColorStop(.7,'#eee');g.addColorStop(1,'#aaa');}
    ctx.shadowColor='#0008';ctx.shadowBlur=8;ctx.shadowOffsetY=4;ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill();ctx.shadowColor='transparent';
    if(state.numbers && s.move>0){ctx.fillStyle=s.color==='B'?'#fff':'#111';ctx.font=`bold ${Math.max(11,step*.28)}px Segoe UI`;ctx.fillText(String(s.move),cx,cy+1);}
  });

  if(state.current>0){
    const last=coordToPoint(state.moves[state.current-1].coord);
    if(last){ctx.strokeStyle='#54f27f';ctx.lineWidth=6;ctx.beginPath();ctx.arc(pad+last.x*step,pad+last.y*step,step*.29,0,Math.PI*2);ctx.stroke();}
  }
}

function drawChart(){
  const ctx=chartCtx,w=chartCanvas.width,h=chartCanvas.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#f7fbfd';ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='#cfdee7';ctx.lineWidth=1;ctx.font='12px Segoe UI';ctx.fillStyle='#6e8292';
  [0,25,50,75,100].forEach(v=>{const y=h-24-v*(h-42)/100;ctx.beginPath();ctx.moveTo(34,y);ctx.lineTo(w-12,y);ctx.stroke();ctx.fillText(v+'%',4,y+4);});
  const maxMove=Math.max(1,state.moves.length,...state.winratePoints.map(p=>p.move));
  const pts=[...state.winratePoints].sort((a,b)=>a.move-b.move);
  function line(valueFn,color){ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();pts.forEach((p,i)=>{const x=34+p.move/maxMove*(w-48);const y=h-24-valueFn(p.value)*(h-42)/100;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();}
  line(v=>v,'#15965f');line(v=>100-v,'#e85a61');
  const x=34+state.current/maxMove*(w-48);ctx.strokeStyle='#2785c7';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,8);ctx.lineTo(x,h-20);ctx.stroke();
}

function updateUI(){
  drawBoard();drawChart();
  $('moveNo').textContent=state.current; $('timeline').max=state.moves.length; $('timeline').value=state.current; $('timelineLabel').textContent=`${state.current} / ${state.moves.length}`;
  $('turn').textContent=(state.current===0?'흑':state.moves[state.current-1].color==='B'?'백':'흑');
  $('blackPlayer').textContent=state.meta.black||'-';$('whitePlayer').textContent=state.meta.white||'-';$('result').textContent=state.meta.result||'-';$('komi').textContent=state.meta.komi||'-';
  $('gameTitle').textContent=state.meta.name||state.meta.event||[state.meta.black,state.meta.white].filter(x=>x&&x!=='-').join(' vs ')||'SGF 대국';
  $('dropHint').style.display=state.moves.length||state.setupBlack.length||state.setupWhite.length?'none':'grid';
  const a=state.analysis.get(state.current);
  if(a){setWinrate(a.blackWinrate);$('recommendation').textContent=a.bestMove||'-';$('recommendationInput').value=a.bestMove||'-';$('scoreInput').value=(a.scoreLead>=0?'흑 +':'백 +')+Math.abs(a.scoreLead).toFixed(1)+'집';$('recommendationNote').value=a.pv&&a.pv.length?'예상 진행: '+a.pv.join(' → '):'AI 추천 변화도 없음';$('commentaryText').value=`${state.current}수 기준 흑 승률 ${a.blackWinrate.toFixed(1)}%, AI 추천수 ${a.bestMove}, 예상 집차 ${a.scoreLead>=0?'흑':'백'} ${Math.abs(a.scoreLead).toFixed(1)}집입니다.`;}
}

async function loadFile(file){
  try{
    const text=await file.text();const parsed=parseSgf(text);Object.assign(state,parsed,{current:0,winratePoints:[{move:0,value:50}],analysis:new Map(),sgfText:text});
    $('sceneMemo').value=`파일: ${file.name}\n총 착수: ${state.moves.length}수`;
    updateUI();
    if ($('autoAnalyzeToggle').checked) setTimeout(()=>$('analyzeBtn').click(), 250);
  }catch(e){$('loadStatus').textContent='실패';alert('SGF를 읽지 못했습니다: '+e.message);}
}

function setMove(n, sound=false){const old=state.current;state.current=Math.max(0,Math.min(state.moves.length,n));updateUI();if(sound&&state.current>old)playStoneSound();}
function stopPlay(){if(state.timer){clearInterval(state.timer);state.timer=null;$('playBtn').textContent='▶';}}
function togglePlay(){if(state.timer){stopPlay();return;}if(state.current>=state.moves.length)state.current=0;$('playBtn').textContent='Ⅱ';state.timer=setInterval(()=>{if(state.current>=state.moves.length){stopPlay();return;}state.current++;updateUI();playStoneSound();},Number($('speedSelect').value));}
function setWinrate(v){v=Math.max(0,Math.min(100,Number(v)||0));$('blackWinrate').textContent=Math.round(v);$('winBar').style.width=v+'%';$('winrateInput').value=v;}


function applyAnalysisPositions(positions){
  if(!Array.isArray(positions)) return;
  state.analysis=new Map(positions.map(p=>[p.move,p]));
  state.winratePoints=positions.map(p=>({move:p.move,value:p.blackWinrate}));
  updateUI();
}

function stopAnalysisPolling(){
  if(state.analysisPoll){clearInterval(state.analysisPoll);state.analysisPoll=null;}
}

async function pollAnalysis(){
  if(!state.analysisJobId)return;
  try{
    const res=await fetch('/analyze/status?id='+encodeURIComponent(state.analysisJobId),{cache:'no-store'});
    const data=await res.json();
    if(!res.ok||!data.ok)throw new Error(data.error||'분석 상태 확인 실패');
    applyAnalysisPositions(data.positions||[]);
    const total=Math.max(1,Number(data.total)||1), completed=Number(data.completed)||0;
    const pct=Math.min(100,Math.round(completed/total*100));
    $('analysisProgressBar').style.width=pct+'%';
    $('analysisStatus').textContent=data.message||`${completed} / ${total} 국면 분석 중`;
    if(data.status==='complete'){
      stopAnalysisPolling();$('analyzeBtn').disabled=false;
      $('analysisProgressBar').style.width='100%';
      if($('autoPlayToggle').checked){
        $('speedSelect').value='3000';setMove(0);setTimeout(togglePlay,500);
      }
    }else if(data.status==='error'){
      stopAnalysisPolling();$('analyzeBtn').disabled=false;
      throw new Error(data.error||'분석 실패');
    }
  }catch(e){
    stopAnalysisPolling();$('analyzeBtn').disabled=false;
    $('analysisStatus').textContent='분석 실패';
    alert('KataGo 분석 실패: '+e.message+'\n\n실행하기.bat으로 실행했는지, D:\\KataGo 경로가 정확한지 확인하세요.');
  }
}

$('analyzeBtn').onclick=async()=>{
  if(!state.sgfText){alert('먼저 SGF 파일을 불러오세요.');return;}
  stopPlay();stopAnalysisPolling();
  $('analysisStatus').textContent='KataGo 분석 작업을 시작합니다…';
  $('analysisProgressBar').style.width='0%';$('analyzeBtn').disabled=true;
  try{
    const res=await fetch('/analyze/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      sgf:state.sgfText,
      katagoPath:$('katagoPath').value,
      modelPath:$('modelPath').value,
      configPath:$('configPath').value,
      visits:Number($('visitsInput').value)||30
    })});
    const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'분석 시작 실패');
    state.analysisJobId=data.jobId;
    state.analysisPoll=setInterval(pollAnalysis,1000);
    pollAnalysis();
  }catch(e){
    $('analyzeBtn').disabled=false;$('analysisStatus').textContent='분석 시작 실패';
    alert('KataGo 분석 시작 실패: '+e.message);
  }
};

$('pathTestBtn').onclick=async()=>{
  try{
    const res=await fetch('/paths/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({katagoPath:$('katagoPath').value,modelPath:$('modelPath').value,configPath:$('configPath').value})});
    const data=await res.json();
    const p=data.paths;
    const lines=[['KataGo',p.katago],['모델',p.model],['설정',p.config]].map(([n,x])=>`${x.exists?'✓':'✗'} ${n}: ${x.path}`);
    alert(lines.join('\n'));
  }catch(e){alert('경로 확인 실패: '+e.message);}
};

$('sampleBtn').onclick=async()=>{try{const r=await fetch('sample.sgf',{cache:'no-store'});if(!r.ok)throw new Error('sample.sgf를 찾을 수 없습니다.');const text=await r.text();const file=new File([text],'sample.sgf',{type:'application/x-go-sgf'});await loadFile(file);}catch(e){alert('샘플 기보 로딩 실패: '+e.message);}};
$('openBtn').onclick=()=>$('fileInput').click();$('fileInput').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('firstBtn').onclick=()=>{stopPlay();setMove(0)};$('prevBtn').onclick=()=>{stopPlay();setMove(state.current-1)};$('nextBtn').onclick=()=>{stopPlay();setMove(state.current+1,true)};$('lastBtn').onclick=()=>{stopPlay();setMove(state.moves.length)};$('playBtn').onclick=togglePlay;
$('coordsToggle').onchange=e=>{state.coords=e.target.checked;drawBoard()};$('numbersToggle').onchange=e=>{state.numbers=e.target.checked;drawBoard()};
$('winrateInput').oninput=e=>setWinrate(e.target.value);$('recommendationInput').oninput=e=>$('recommendation').textContent=e.target.value.toUpperCase();
$('addPointBtn').onclick=()=>{const v=Number($('winrateInput').value);state.winratePoints=state.winratePoints.filter(p=>p.move!==state.current);state.winratePoints.push({move:state.current,value:Math.max(0,Math.min(100,v))});drawChart();};
$('clearPointsBtn').onclick=()=>{state.winratePoints=[{move:0,value:50}];drawChart();};
$('timeline').oninput=e=>{stopPlay();setMove(Number(e.target.value));};
$('recordingBtn').onclick=async()=>{document.body.classList.toggle('recording');$('recordingBtn').textContent=document.body.classList.contains('recording')?'녹화 종료':'녹화 모드'; if(document.body.classList.contains('recording')&&!document.fullscreenElement){try{await document.documentElement.requestFullscreen()}catch(_){}}};
$('fullscreenBtn').onclick=async()=>{try{if(!document.fullscreenElement){await document.documentElement.requestFullscreen();document.body.classList.add('fullscreen-ui')}else{await document.exitFullscreen();}}catch(e){alert('전체화면 전환 실패: '+e.message)}};
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)document.body.classList.remove('fullscreen-ui')});

const dz=$('dropZone');['dragenter','dragover'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('dragover')}));['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('dragover')}));dz.addEventListener('drop',e=>{const f=[...e.dataTransfer.files].find(f=>f.name.toLowerCase().endsWith('.sgf'));if(f)loadFile(f);else alert('SGF 파일을 놓아주세요.')});
window.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName))return;if(e.key==='ArrowLeft')setMove(state.current-1);if(e.key==='ArrowRight')setMove(state.current+1,true);if(e.key===' ') {e.preventDefault();togglePlay();}if(e.key.toLowerCase()==='r'){$('recordingBtn').click();}if(e.key==='Escape'&&document.body.classList.contains('recording')){$('recordingBtn').click();}});

setWinrate(50);updateUI();

document.addEventListener('pointerdown',()=>{try{ensureAudioContext()}catch(_){}},{once:true});
