import json, os, re, subprocess, threading, time, uuid, webbrowser
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BASE = os.path.dirname(os.path.abspath(__file__))
PORT = 8765
JOBS = {}
JOBS_LOCK = threading.Lock()


def sgf_prop(root, key, default=''):
    m = re.search(r'(?:^|[;(])' + re.escape(key) + r'\[([^\]]*)\]', root)
    return m.group(1) if m else default


def sgf_to_query(text, visits):
    root_end = text.find(';', 2)
    root = text[:root_end if root_end >= 0 else len(text)]
    size = int(sgf_prop(root, 'SZ', '19') or 19)
    komi = float(sgf_prop(root, 'KM', '7.5') or 7.5)
    rules = 'japanese'
    ru = sgf_prop(root, 'RU', '').lower()
    if 'chinese' in ru:
        rules = 'chinese'
    elif 'aga' in ru:
        rules = 'aga'
    elif 'tromp' in ru:
        rules = 'tromp-taylor'

    moves = []
    letters = 'ABCDEFGHJKLMNOPQRSTUVWXYZ'
    for color, coord in re.findall(r';\s*([BW])\[([^\]]*)\]', text):
        if not coord:
            loc = 'pass'
        else:
            x, y = ord(coord[0]) - 97, ord(coord[1]) - 97
            if x < 0 or y < 0 or x >= size or y >= size:
                continue
            loc = f'{letters[x]}{size-y}'
        moves.append([color, loc])

    return {
        'id': 'hongtai-game',
        'moves': moves,
        'rules': rules,
        'komi': komi,
        'boardXSize': size,
        'boardYSize': size,
        'analyzeTurns': list(range(len(moves) + 1)),
        'maxVisits': max(5, int(visits)),
        'analysisPVLen': 8,
        'includeOwnership': False,
        'includePolicy': False,
    }


def compact_result(obj):
    root = obj.get('rootInfo', {})
    infos = sorted(obj.get('moveInfos', []), key=lambda x: x.get('order', 999))
    best = infos[0] if infos else {}
    return {
        'move': int(obj.get('turnNumber', 0)),
        'blackWinrate': round(float(root.get('winrate', .5)) * 100, 2),
        'scoreLead': round(float(root.get('scoreLead', 0)), 2),
        'bestMove': best.get('move', '-'),
        'pv': best.get('pv', [])[:8],
        'visits': int(root.get('visits', 0) or 0),
    }


def analyze_job(job_id, payload):
    exe = payload.get('katagoPath', '').strip()
    model = payload.get('modelPath', '').strip()
    cfg = payload.get('configPath', 'analysis_hongtai.cfg').strip()
    if not os.path.isabs(cfg):
        cfg = os.path.join(BASE, cfg)

    try:
        for path, label in [(exe, 'KataGo 실행 파일'), (model, '신경망 모델'), (cfg, '분석 설정 파일')]:
            if not os.path.exists(path):
                raise FileNotFoundError(f'{label}을 찾을 수 없습니다: {path}')

        query = sgf_to_query(payload.get('sgf', ''), payload.get('visits', 30))
        expected = len(query['analyzeTurns'])
        with JOBS_LOCK:
            JOBS[job_id].update(status='running', total=expected, message='KataGo 시작 중…')

        cmd = [exe, 'analysis', '-config', cfg, '-model', model]
        proc = subprocess.Popen(
            cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding='utf-8', errors='replace', bufsize=1
        )
        proc.stdin.write(json.dumps(query, separators=(',', ':')) + '\n')
        proc.stdin.flush()
        proc.stdin.close()

        deadline = time.time() + max(300, expected * 15)
        results = {}
        while len(results) < expected and time.time() < deadline:
            line = proc.stdout.readline()
            if not line:
                if proc.poll() is not None:
                    break
                time.sleep(.05)
                continue
            try:
                obj = json.loads(line)
                if obj.get('id') == 'hongtai-game' and not obj.get('isDuringSearch', False):
                    item = compact_result(obj)
                    results[item['move']] = item
                    ordered = [results[k] for k in sorted(results)]
                    with JOBS_LOCK:
                        JOBS[job_id].update(
                            completed=len(ordered), positions=ordered,
                            message=f'{len(ordered)} / {expected} 국면 분석 중'
                        )
            except Exception:
                continue

        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
        stderr = proc.stderr.read()[-2500:]
        if not results:
            raise RuntimeError('KataGo 분석 결과가 없습니다.\n' + stderr)

        ordered = [results[k] for k in sorted(results)]
        with JOBS_LOCK:
            JOBS[job_id].update(
                status='complete', completed=len(ordered), positions=ordered,
                message=f'분석 완료: {len(ordered)}개 국면', stderr=stderr[-800:]
            )
    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id].update(status='error', error=str(e), message='분석 실패')


class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        path = urlparse(path).path.lstrip('/') or 'index.html'
        return os.path.join(BASE, path)

    def json_response(self, data, code=200):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/analyze/status':
            job_id = parse_qs(parsed.query).get('id', [''])[0]
            with JOBS_LOCK:
                job = JOBS.get(job_id)
                data = dict(job) if job else None
            if data is None:
                self.json_response({'ok': False, 'error': '분석 작업을 찾을 수 없습니다.'}, 404)
            else:
                self.json_response({'ok': True, **data})
            return
        super().do_GET()

    def do_POST(self):
        n = int(self.headers.get('Content-Length', '0'))
        try:
            payload = json.loads(self.rfile.read(n).decode('utf-8'))
        except Exception:
            self.json_response({'ok': False, 'error': '잘못된 요청입니다.'}, 400)
            return

        if self.path == '/paths/check':
            cfg = payload.get('configPath', 'analysis_hongtai.cfg').strip()
            if not os.path.isabs(cfg):
                cfg = os.path.join(BASE, cfg)
            paths = {
                'katago': payload.get('katagoPath', '').strip(),
                'model': payload.get('modelPath', '').strip(),
                'config': cfg,
            }
            self.json_response({'ok': True, 'paths': {k: {'path': v, 'exists': os.path.exists(v)} for k, v in paths.items()}})
            return

        if self.path == '/analyze/start':
            job_id = uuid.uuid4().hex
            with JOBS_LOCK:
                JOBS[job_id] = {'status': 'queued', 'completed': 0, 'total': 0, 'positions': [], 'message': '대기 중'}
            threading.Thread(target=analyze_job, args=(job_id, payload), daemon=True).start()
            self.json_response({'ok': True, 'jobId': job_id})
            return

        self.send_error(404)

    def log_message(self, fmt, *args):
        pass


if __name__ == '__main__':
    os.chdir(BASE)
    url = f'http://127.0.0.1:{PORT}/'
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    print('Hongtai Go Studio v0.5 실행 중:', url)
    print('이 창을 닫으면 Studio도 종료됩니다.')
    ThreadingHTTPServer(('127.0.0.1', PORT), Handler).serve_forever()
