@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 studio_server.py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python studio_server.py
  ) else (
    echo Python 3가 필요합니다. https://www.python.org 에서 설치하며 Add Python to PATH를 체크하세요.
    pause
  )
)
